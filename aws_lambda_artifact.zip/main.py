from fastapi import FastAPI
from mangum import Mangum
from uvicorn import run
from pymongo import MongoClient

app = FastAPI()
handler = Mangum(app)

client = MongoClient("mongodb://localhost:27017/")
db = client["car_db"]
collection = db["car_db"]


@app.get('/')
async def hello():
    return {'message': 'hello from coding with roby'}

if __name__ == '__main__':
    run(app, host='0.0.0.0', port=8000)
